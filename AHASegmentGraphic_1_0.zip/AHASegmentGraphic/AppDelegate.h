//
//  AppDelegate.h
//  AHASegmentGraphic
//
//  Created by Daniel Schroth on 22.08.22.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

